# مواصفات إعادة بناء منصة Aplus WiFi SaaS

## 0. طبيعة هذه الوثيقة

هذه الوثيقة هي **مواصفة إعادة بناء تنفيذية** مستخرجة من الواجهات العامة والملفات الأمامية المتاحة للنطاقات المفحوصة. يمكن إعطاؤها لوكيل ذكاء اصطناعي أو فريق تطوير ليبدأ بناء مشروع جديد من الصفر.

هذه ليست الشفرة الأصلية وليست كشفاً للباك إند الخاص بالمشغل. الكشط يثبت ما ظهر في الواجهة والملفات العامة، بينما بعض تفاصيل قاعدة البيانات والتكاملات الداخلية غير مكشوفة. لذلك يجب تنفيذ الأجزاء غير المرئية وفق البدائل الموثقة في قسم الافتراضات، مع إبقاء التصميم قابلاً للاستبدال.

## 1. الهدف النهائي

بناء منصة SaaS متعددة المستأجرين لإدارة شبكات WISP/WiFi. كل شبكة عميلة تحصل على نطاق فرعي ولوحة تشغيل معزولة، بينما تستخدم جميع الشبكات تطبيقاً مركزياً واحداً.

يجب أن تنتج المنصة الجديدة ثلاثة مستويات:

1. **موقع تسويقي عام** على نطاق رئيسي.
2. **لوحة مستأجر** لكل شبكة على نطاق فرعي.
3. **لوحة منصة مركزية** لإدارة المستأجرين والخطط والاشتراكات والدعم.

يجب أن تكون الواجهة عربية RTL أولاً، مع قابلية إضافة الإنجليزية، وأن تعمل في بيئات اتصال ضعيف، وأن تدعم النشر السحابي أو المحلي.

## 2. النطاقات والهوية

النموذج المستهدف:

```text
apluswifi.com                         الموقع التسويقي
{tenant-slug}.apluswifi.com           لوحة الشبكة العميلة
demo.apluswifi.com                    مستأجر تجريبي
admin.apluswifi.com                   لوحة مشغل المنصة، اختيارية
```

أمثلة المستأجرين المرصودين:

```text
al3alamiah-sna-ac.apluswifi.com
alheziazi-sna-ac.apluswifi.com
```

يقرأ الخادم قيمة `Host`، ويبحث عن المستأجر، ثم يحمّل اسم الشبكة وشعارها وإعداداتها وصلاحياتها وبياناتها.

## 3. البنية المقترحة

```text
Browser
  │
  ▼
Cloudflare / DNS / TLS / Wildcard DNS
  │
  ▼
Reverse Proxy + Web Server
  │
  ▼
Laravel Application
  ├── Tenant Resolver Middleware
  ├── Authentication + CSRF + Sessions
  ├── Inertia Responses
  ├── Authorization Policies
  ├── Accounts Module
  ├── Vouchers Module
  ├── Reports Module
  ├── SMS Module
  ├── Backup/Dumper Module
  ├── Network/RADIUS Integration
  ├── Queue + Scheduler
  └── Central Admin Module
       │
       ├── MySQL/MariaDB أو PostgreSQL
       ├── Redis/Cache/Queues
       ├── Object/File Storage
       ├── RADIUS Service
       └── MikroTik API/Accounting
```

التنفيذ المرجح والمناسب لإعادة البناء هو Laravel + Inertia.js + Vue 3 + TypeScript اختياري + Tailwind CSS + Laravel Sanctum/Jetstream أو بديل مصادقة مكافئ.

## 4. هوية المستأجر وعزله

أنشئ جدول `tenants` يحتوي على الأقل على:

```text
id
name
slug
subdomain
custom_domain
site_name
logo_path
share_image_path
status
plan_id
trial_ends_at
settings_json
created_at
updated_at
```

أنشئ `TenantResolver` middleware يقوم بالخطوات التالية:

1. يقرأ `request()->getHost()`.
2. يستخرج النطاق أو النطاق الفرعي.
3. يبحث عن المستأجر النشط.
4. يرفض النطاق غير المعروف برسالة واضحة.
5. يحقن المستأجر الحالي في حاوية التطبيق وطلب HTTP.
6. يضيف المستأجر إلى سياق المصادقة والاستعلامات.

يجب عدم الاعتماد على `tenant_id` القادم من المتصفح. يجب أخذه من النطاق والجلسة والصلاحيات فقط.

## 5. نموذج الأدوار

الأدوار المقترحة:

| الدور | الصلاحيات |
|---|---|
| Platform Admin | إدارة كل المستأجرين والخطط والدعم والإعدادات المركزية |
| Tenant Owner | إدارة شبكة مستأجر واحد وجميع وحداته |
| Network Manager | تشغيل الكروت والباقات والجلسات والأجهزة |
| Accountant | المحاسبة والفواتير والصناديق والتقارير المالية |
| Seller | بيع الكروت ومتابعة الرصيد والمبيعات |
| Support | القراءة والمساعدة دون صلاحيات مالية خطرة |
| Viewer | قراءة التقارير والبيانات فقط |

أنشئ `users` و`roles` و`permissions` وعلاقة `tenant_user`. ادعم مستخدماً واحداً في أكثر من مستأجر إذا احتاج المشغل ذلك.

## 6. المصادقة والأمان

نفّذ:

- صفحة `/login` بهوية المستأجر.
- جلسات آمنة عبر Cookie.
- CSRF لكل النماذج والطلبات الكتابية.
- تجديد معرف الجلسة بعد الدخول.
- تسجيل الخروج من كل الجلسات.
- تغيير كلمة المرور.
- 2FA للمستخدمين الإداريين.
- سياسات Authorization لكل موديل.
- سجل تدقيق `audit_logs` لكل إنشاء وتعديل وحذف وتصدير.
- تحديد معدل الطلبات.
- تشفير أسرار MikroTik وRADIUS.
- منع تسريب بيانات مستأجر إلى آخر.

مؤشرات الواجهة المرصودة تشمل `XSRF-TOKEN` و`aplus_session` و`csrf-token` وخصائص Jetstream للمصادقة والجلسات.

## 7. الوحدات الوظيفية المطلوبة

### 7.1 الإعدادات العامة

المسارات المرصودة أو المطلوبة:

```text
/settings
/user/profile
/permissions/user
/backup
/monitor/panel
/notification
```

الميزات:

- اسم الشبكة وشعارها وصورة المشاركة.
- إعدادات اللغة والمنطقة الزمنية والعملة.
- بيانات الاتصال.
- إدارة المستخدمين والأدوار.
- إعدادات النسخ الاحتياطي.
- مراقبة الخادم.
- مركز الإشعارات.
- الملف الشخصي والجلسات وكلمة المرور.

### 7.2 خدمات الشبكة

```text
/service/change_speed
/service/change_speed/history
/service/change_group
/service/points
/service/points/statistics
/service/points/group
/service/charging_points
/service/charging_points/statistics
/competitions
/competitions/statistics
/service/sms
/service/sms/settings
/service/sms/notifications
/service/macsec/statistics
```

الميزات:

- تغيير سرعة المشترك أو الباقة.
- سجل تغييرات السرعة.
- تحويل المشتركين بين الباقات.
- برنامج النقاط وحركة النقاط ونقاط المستخدمين.
- نقاط الشحن وحركتها.
- المسابقات وحركتها.
- إرسال الرسائل النصية وقوالبها وإشعاراتها.
- حماية MAC ومراقبة العناوين المكررة.

### 7.3 نظام الكروت والباقات

```text
/cards/catagory
/cards/groups
/cards/design
/cards/cards
/cards/printer
/cards/subscriptions
/cards/import/options
```

الميزات:

- فئات الكروت.
- الباقات والأسعار والمدة والسرعة وحصة البيانات.
- إنشاء كرت واحد أو مجموعة كروت.
- حالات الكرت: مطبوع، فعال، مستخدم، منتهٍ، موقوف.
- تصميم وطباعة الكروت.
- التصدير إلى Excel/PDF.
- استيراد الكروت.
- تجديد الكروت.
- حذف أو أرشفة الكروت.
- ربط الكرت بالبائع أو نقطة البيع.

النموذج المقترح:

```text
card_categories
card_groups/packages
cards
card_print_jobs
card_status_history
card_import_jobs
card_designs
subscriptions
```

### 7.4 المحاسبة والمخزون

```text
/accounts/open
/accounts/account
/accounts/journal_entry
/accounts/cash
/accounts/warehous
/accounts/transaction
/accounts/receive
/accounts/customers
/accounts/invoices
/accounts/returns
/accounts/payment
/accounts/receipt
```

الميزات:

- الأرصدة الافتتاحية.
- شجرة الحسابات.
- القيود المحاسبية.
- الصناديق.
- المخازن.
- التحويلات المخزنية.
- الاستلامات.
- بيانات العملاء.
- فواتير المبيعات.
- مرتجعات المبيعات.
- سندات القبض والصرف.
- دفتر الأستاذ وحركة الحساب.

النماذج المقترحة:

```text
accounts
account_groups
journal_entries
journal_entry_lines
cash_boxes
warehouses
warehouse_transactions
warehouse_receipts
customers
invoices
invoice_items
return_invoices
payments
receipts
```

يجب استخدام معاملات قاعدة البيانات للمستندات المالية، ومنع تعديل المستند المرحل دون عملية عكس أو صلاحية خاصة.

### 7.5 التقارير

```text
/accounts/report/payment
/accounts/report/receipt
/accounts/report/invoice
/accounts/reports
/cards/report/sales
/cards/report/allsales
/cards/report/sales_data
/cards/report/data
/cards/report/inventory
/reports/more
```

الميزات:

- تقارير سندات الصرف والقبض.
- تقارير الفواتير النقدية والآجلة.
- كشف الحساب.
- إجمالي وتحليلي المبيعات.
- استهلاك البيانات مع المبيعات.
- استهلاك البيانات العام.
- تقرير المخزون.
- فلاتر التاريخ والنص والرقم والفرز والاختيار.
- حفظ الفلاتر.
- جدولة التقارير.
- سجل التسليم.
- إرسال التقرير إلى Telegram إذا تم تفعيل التكامل.

الحزم المرصودة تكشف مكونات مثل `Generator`, `Schedules`, `Logs`, `SavedFiltersManager`, `DeliveryHistory` و`TelegramRecipientSelector`.

### 7.6 الجلسات

```text
/cards/sessions/active
/cards/sessions/all
/cards/sessions/summary
```

اعرض:

- الجلسات الحالية.
- المستخدم والكرت.
- IP وMAC.
- الراوتر.
- وقت البداية والنهاية.
- البيانات الداخلة والخارجة.
- المدة.
- حالة الاتصال.
- ملخص الجلسات حسب اليوم أو الباقة أو الجهاز.

### 7.7 النسخ الاحتياطية

الوحدة الظاهرة باسم `dumper` وتشمل صفحات ومكونات للنسخ والإعدادات والرفع.

نفّذ:

- نسخة يدوية.
- نسخة مجدولة.
- رفع إلى تخزين خارجي.
- تنزيل واستعادة بصلاحية عليا.
- سجل عمليات النسخ.
- تشفير الملفات.
- التحقق من سلامة الملف قبل الاستعادة.
- عدم السماح باستعادة نسخة مستأجر فوق مستأجر آخر دون تأكيد إداري واضح.

### 7.8 التكامل مع MikroTik وRADIUS

وفّر إعدادات لكل مستأجر:

```text
radius_host
radius_port
auth_secret
accounting_secret
mikrotik_host
mikrotik_api_port
mikrotik_username
mikrotik_password
connection_mode
```

ادعم على الأقل:

- Hotspot.
- PPPoE.
- إنشاء وتحديث ملفات السرعة.
- فصل الجلسة.
- قراءة Accounting.
- ربط أكثر من راوتر.
- تحديد `tenant_id` لكل راوتر أو Realm.
- اختبار الاتصال.
- تدوير الأسرار.

لا تخزن الأسرار في JavaScript أو HTML. استخدم خدمة أسرار أو تشفيراً في قاعدة البيانات.

## 8. واجهات API المقترحة

استخدم واجهات REST أو Inertia actions، مع تفضيل REST للعمليات الخارجية:

```text
GET    /api/tenant/context
GET    /api/dashboard/summary
GET    /api/cards
POST   /api/cards
PUT    /api/cards/{id}
POST   /api/cards/import
POST   /api/cards/{id}/renew
POST   /api/cards/{id}/stop
GET    /api/packages
POST   /api/packages
GET    /api/sessions/active
POST   /api/sessions/{id}/disconnect
GET    /api/reports/sales
GET    /api/reports/data
GET    /api/accounts/tree
POST   /api/journal-entries
GET    /api/invoices
POST   /api/invoices
GET    /api/backups
POST   /api/backups
GET    /api/notifications
```

كل endpoint يجب أن يطبق:

```text
authentication
current tenant resolution
authorization policy
validation
audit logging
pagination/filtering
```

## 9. قاعدة البيانات المقترحة

ابدأ بقاعدة مشتركة مع `tenant_id` في كل جدول أعمال، لأنها أبسط نموذج SaaS قابل للتشغيل، مع عزل إضافي عبر Global Scopes وPolicies. اجعل طبقة الوصول قابلة للتحويل لاحقاً إلى قاعدة منفصلة لكل مستأجر.

الجداول الأساسية:

```text
tenants
plans
subscriptions
users
roles
permissions
tenant_user
site_settings
routers
radius_servers
packages
card_categories
cards
card_status_history
card_designs
print_jobs
customers
accounts
journal_entries
journal_entry_lines
cash_boxes
warehouses
warehouse_transactions
invoices
invoice_items
returns
payments
receipts
network_sessions
speed_change_logs
points
points_transactions
sms_settings
sms_messages
notifications
reports
saved_report_filters
scheduled_reports
report_delivery_logs
backups
audit_logs
```

## 10. لوحة المنصة المركزية

أنشئ لوحة مستقلة للمشغل، لأنها غير ظاهرة في الكشط لكنها ضرورية لنموذج SaaS:

- إنشاء وتعديل وإيقاف مستأجر.
- إنشاء النطاق الفرعي.
- ربط نطاق مخصص.
- اختيار الخطة.
- بدء التجربة وإنهاؤها.
- إدارة الاشتراك والدفع.
- إدارة مستخدم مالك الشبكة.
- عرض الاستخدام.
- الدعم والتذاكر.
- إعلانات النظام.
- مراقبة الخدمات.
- إدارة النسخ والترقيات.
- سجلات الدخول والحوادث.

## 11. الموقع التسويقي

الموقع الرئيسي المرصود هو Single Page Application ويحتوي على الأقسام التالية:

- الرئيسية.
- المميزات.
- لماذا نحن.
- الأسعار.
- تواصل معنا.
- طلب نسخة تجريبية.
- إحصائيات الكروت والجلسات والمبيعات والفواتير.
- مشكلات إدارة الكروت وقواعد البيانات والضغط على MikroTik والحسابات.
- نظام RADIUS.
- الاستضافة المحلية والسحابية.
- شهادات العملاء.
- نموذج التواصل.
- سياسة الخصوصية وشروط الخدمة واتفاقية الترخيص.

القسم التسويقي لا يكفي لتشغيل النظام؛ يجب أن يرسل طلبات التجربة إلى خدمة CRM أو endpoint آمن، لا إلى JavaScript ثابت فقط.

## 12. المكدس التقني المثبت أو المرجح

| الطبقة | الاختيار |
|---|---|
| Backend | Laravel، بثقة عالية |
| Frontend | Vue، بثقة عالية |
| Bridge | Inertia.js، بثقة عالية |
| Auth scaffold | Laravel Jetstream، بثقة عالية |
| HTTP client | Axios، مثبت في الحزم |
| Route helper | Ziggy، مثبت في الحزم |
| State | Pinia، مؤشر ظاهر |
| Charts | Chart.js، مؤشر ظاهر |
| Notifications | SweetAlert، مؤشر ظاهر |
| Realtime | Pusher، احتمال مدعوم بحزمة العميل |
| Database | غير مثبت؛ MySQL/MariaDB خيار أولي |
| Cache/queue | غير مثبت؛ Redis خيار أولي |
| Web server | غير مثبت؛ Nginx/Apache محتمل |
| Edge | Cloudflare ظاهر في الرؤوس |

## 13. الملفات التي تم كشطها

### حزمة الموقع الرئيسي

الحزمة الحالية:

```text
apluswifi-public-frontend-complete.zip
```

وتتضمن:

```text
public/apluswifi.com/index.html
public/apluswifi.com/assets/index-eIGK7c5H.js
public/apluswifi.com/assets/vendor-xzUBTsyd.js
public/apluswifi.com/assets/icons-BFaLlSR8.js
public/apluswifi.com/assets/animations-CZQxtya4.js
public/apluswifi.com/assets/index-Dh_5nObk.css
public/apluswifi.com/logo.png
public/apluswifi.com/crawl-manifest.json
public/apluswifi.com/extracted-content.md
public/apluswifi.com/homepage-screenshot.webp
public/apluswifi.com/README.md
```

الحزمة تحتوي على HTML الموقع العام وموارده المحلية وفهرس الروابط والموارد والمحتوى النصي واللقطة المرئية.

### حزمة لوحة التحكم الموسعة

الحزمة الحالية:

```text
apluswifi-demo-frontend-complete.zip
```

وتتضمن:

```text
admin/index.html
admin/login/index.html
admin/routes.json
admin/route-capture.json
admin/resource_urls.txt
admin/README.md
admin/routes/*/index.html
admin/assets/build/assets/**/*.js
admin/assets/build/assets/**/*.css
admin/assets/**/*.png
admin/assets/**/*.svg
admin/assets/**/*.woff
```

يوجد ملف HTML محلي لكل مسار داخلي فريد تم اكتشافه، إضافة إلى الأصول المجمعة المشتركة. عدد المسارات المحلية في النسخة الموسعة هو 61، وعدد ملفات ZIP السابق كان 784.

### ملفات التحليل

```text
apluswifi-platform-analysis.md
bundle-analysis.json
probe/*.txt
probe/*.html
```

هذه الملفات ليست جزءاً من التطبيق المطلوب تشغيله، لكنها تحفظ الأدلة والاستنتاجات التي بُنيت عليها هذه المواصفة.

## 14. خطة تنفيذ وكيل الذكاء الاصطناعي

ينبغي على الوكيل المنفذ اتباع المراحل التالية:

### المرحلة A: تهيئة المشروع

1. إنشاء مستودع Laravel.
2. تثبيت Inertia وVue وJetstream أو بديل مكافئ.
3. إعداد RTL وTailwind والتوطين.
4. إعداد Docker للتطوير والإنتاج.
5. إعداد CI وتشغيل الاختبارات.

### المرحلة B: النواة متعددة المستأجرين

1. إنشاء migrations للمستأجرين والخطط والمستخدمين.
2. كتابة `TenantResolver`.
3. كتابة `TenantContext`.
4. إضافة Global Scopes.
5. إضافة Policies واختبارات منع تسرب البيانات.
6. إنشاء نطاق تجريبي.

### المرحلة C: المصادقة والصلاحيات

1. بناء الدخول والخروج وتغيير كلمة المرور.
2. إضافة 2FA.
3. إضافة الأدوار والصلاحيات.
4. إضافة audit logs.
5. اختبار الجلسات عبر أكثر من نطاق.

### المرحلة D: الوحدات التشغيلية

تنفيذ الحسابات، الكروت، الباقات، الجلسات، التقارير، الرسائل، النسخ، التكاملات، ثم المحاسبة وفق ترتيب يعتمد على التبعيات.

### المرحلة E: الموقع التسويقي

إعادة بناء أقسام الموقع العام، وربط نموذج طلب التجربة بخدمة المنصة المركزية.

### المرحلة F: التكاملات

إضافة MikroTik وRADIUS وSMS وTelegram والتخزين الخارجي كموصلات قابلة للتبديل، مع محاكيات Mock في الاختبارات.

### المرحلة G: الاختبارات

يجب أن تشمل:

- اختبارات عزل المستأجرين.
- اختبارات الصلاحيات.
- اختبارات الفواتير والقيود.
- اختبارات حالات الكروت.
- اختبارات الجلسات.
- اختبارات استيراد وتصدير الملفات.
- اختبارات النسخ والاستعادة.
- اختبارات النطاقات الفرعية.
- اختبارات انقطاع RADIUS/MikroTik.
- اختبارات اتصال ضعيف.

### المرحلة H: النشر

1. إعداد wildcard DNS وTLS.
2. نشر Laravel خلف reverse proxy.
3. تشغيل queue workers وscheduler.
4. تهيئة التخزين والنسخ الاحتياطية.
5. تهيئة المراقبة والتنبيهات.
6. إنشاء أول مستأجر.
7. اختبار نطاقين منفصلين ببيانات مختلفة.

## 15. معايير القبول

يعتبر البناء ناجحاً عندما:

- يفتح الموقع العام ويعرض الأقسام العربية RTL.
- يمكن إنشاء مستأجر جديد من لوحة المنصة.
- يحصل المستأجر على نطاق فرعي.
- تظهر صفحة دخول باسم الشبكة وشعارها.
- لا يستطيع مستخدم مستأجر رؤية بيانات مستأجر آخر.
- يعمل إنشاء الكروت وتغيير حالتها وطباعة تفاصيلها.
- تعمل الباقات والجلسات والتقارير الأساسية.
- تعمل الفواتير والقبض والصرف والقيود بطريقة متسقة.
- تعمل النسخ الاحتياطية مع سجل تدقيق.
- يمكن ربط راوتر تجريبي وRADIUS Mock.
- يمكن تشغيل النظام محلياً أو سحابياً.
- توجد اختبارات آلية للعمليات الحساسة.

## 16. حدود إعادة البناء

لا يمكن لوكيل واحد، اعتماداً على ملفات الكشط فقط، أن يضمن نسخة مطابقة حرفياً للباك إند الأصلي؛ لأن الكشط لا يحتوي على Controllers أو Models أو migrations أو أسرار التكامل أو قاعدة البيانات أو لوحة الإدارة المركزية.

النسخة القابلة لإعادة البناء يجب أن تعتبر أسماء الوحدات والمسارات والواجهات المرصودة مواصفات توافق، وأن تعتبر نموذج البيانات والتكاملات غير المرئية قرارات تنفيذية قابلة للاستبدال.

## 17. النتيجة النهائية

المنتج المطلوب ليس موقعاً ثابتاً، بل **منصة تشغيل شبكات متعددة المستأجرين**. الموقع العام يجذب العملاء، ونطاق المستأجر يحدد مساحة شبكة مستقلة منطقياً، والباك إند المركزي يدير الهوية والبيانات والتكاملات والتقارير والمحاسبة.

أقرب إعادة بناء وفية للأدلة هي:

```text
Laravel monolith modular
+ Inertia
+ Vue 3
+ Jetstream/Sanctum
+ Tenant middleware by hostname
+ Tenant-scoped database access
+ Accounts module
+ Vouchers module
+ Reports module
+ SMS module
+ Backup module
+ MikroTik/RADIUS adapters
+ Central SaaS admin
+ RTL Arabic marketing site
```

هذا يعطي الوكيل نقطة انطلاق كافية لبناء مشروع كامل وظيفياً من الصفر، لكنه لا يحول الاستنتاجات غير المرئية إلى حقائق عن النظام الأصلي.

## المراجع

[1]: https://apluswifi.com/ "الموقع الرئيسي لنظام Aplus WiFi"
[2]: https://demo.apluswifi.com/login "صفحة دخول البيئة التجريبية"
[3]: https://al3alamiah-sna-ac.apluswifi.com/login "صفحة دخول شبكة العالمية"
[4]: https://alheziazi-sna-ac.apluswifi.com/login "صفحة دخول شبكة الحزيزي نت اللاسلكية"
[5]: https://inertiajs.com/how-it-works "Inertia.js — How It Works"
[6]: https://jetstream.laravel.com/introduction.html "Laravel Jetstream — Introduction"
[7]: https://laravel.com/docs/12.x/session "Laravel — HTTP Session"
